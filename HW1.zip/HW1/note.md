### css 中margin和padding的区别

margin是外边距，padding是内边距。

margin是用来设置元素与元素之间的距离，padding是用来设置元素内部的内容与元素的边框之间的距离。

